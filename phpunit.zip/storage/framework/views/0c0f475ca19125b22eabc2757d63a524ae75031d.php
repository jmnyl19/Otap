<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
<script src="<?php echo e(asset('js/sidenav.js')); ?>"></script>


<header class="header" id="header">
  <div class="header_toggle" id="header-toggle"> <i class="bi bi-list"></i> </div>
  <div class="header_img col-auto col-md-2"><i class="bi bi-calendar2-week-fill h3"></i> <h6 id="datetime"></h6> </div>
</header>
<div class="l-navbar" id="nav-bar">
  <nav class="nav">
      <div> 
        <a href="<?php echo e(route('landingpage')); ?>" class="nav_logo"> <i class='bx bx-layer nav_logo-icon'></i> <span class="nav_logo-name"><img class="mx-auto d-block" width="150" height="150" src="<?php echo e(asset('assets/otaplogo.png')); ?>" alt="user profile"></span> </a>
        <a href="#" class="nav_logo">  <span class="nav_logo-name">Barangay <?php echo e(auth()->user()->barangay); ?></span> </a>
          <div class="nav_list"> 
            <a href="<?php echo e(route('landingpage')); ?>" class="nav_link"> <i class="bi bi-clipboard-data nav_icon"></i> <span class="nav_name">Dashboard</span> </a> 
            <a href="<?php echo e(route('latest')); ?>" class="nav_link"> <i class="bi bi-exclamation-circle nav_icon"></i> <span class="nav_name">Incident Reports</span> </a> 
            <a href="<?php echo e(route('forwarded')); ?>" class="nav_link"> <i class="bi bi-send-exclamation nav_icon"></i> <span class="nav_name">Forwarded Emergency</span> </a>
            <a class="dropdown-btn nav_link">
              <i class="bi bi-caret-down-fill"></i>
              <span>Dropdown</span>
            </a>
            <div class="dropdown-container nav_link">
              <a class="nav_link" onclick="window.location='<?php echo e(route('pendingpage')); ?>'"><i class="bi bi-exclamation-triangle"></i><span class="nav_name">Pending</span></a>
              <a class="nav_link" onclick="window.location='<?php echo e(route('responding')); ?>'"><i class="bi bi-arrow-repeat"></i><span class="nav_name">Responding</span></a>
              <a class="nav_link" onclick="window.location='<?php echo e(route('forwarded')); ?>'"><i class="bi bi-send-exclamation"></i><span class="nav_name">Forwarded</span></a>
              <a class="nav_link" onclick="window.location='<?php echo e(route('completedpage')); ?>'"><i class="bi bi-check-circle"></i><span class="nav_name">Completed</span></a>
            </div>
 
          </div>
      </div> 
      <a href="/logout" class="nav_link"> <i class="bi bi-box-arrow-left"></i> <span class="nav_name">SignOut</span> </a>
  </nav>
</div>

<?php /**PATH C:\xampp\htdocs\Otap\resources\views/sidebar/sidenav.blade.php ENDPATH**/ ?>