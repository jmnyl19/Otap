
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/landingpage.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/sidenav.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


    <?php echo $__env->make('sidebar.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="latest-container p-4 mt-5">
        <h1>Incident Reports</h1>

        <div class="requests" style="width: 95%; margin: 10px">
            <div class="shadow p-4 mb-4 bg-white rounded " >
                <div class="row align-items-center">
                    <div class="col">
                    <?php $__currentLoopData = $reportedIncident; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <div class="btn btn-primary shadow p-1 mb-1 bg-white rounded " type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($report->id); ?>" style="width: 100%; margin: 10px; border: none">
                        <div class="card-body">
                            <div class="row align-items-center text-start">
                                <div class="col-auto">
                                    <h1 style="color: red">|</h1>
                                </div>
                                <div class="col">
                                    <h5 style="color: #000"><?php echo e($report->location); ?></h5>
                                                                
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Modal -->
                        <div class="modal modal-lg fade" id="exampleModal<?php echo e($report->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>

                                <div class="modal-body justify-content-center">
                                    <!-- <iframe width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.app.goo.gl/SsbbLj4qt86JPkPG9"></iframe> -->
                                    <h4 style="text-align: center">Incident Report</h4>

                                    <div class="square-container p-20">
                                        <div class="shadow p-1 mb-1 bg-white rounded">
                                        <div class="container row ps-5">
                                        <img src="..." class="img-thumbnail mt-3" alt="...">
                                        <form class="row gt-3 gx-3" action="" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-md-6 mt-3">
                                            <label for="inputName" class="form-label mb-0">Name</label>
                                            <input type="text" class="form-control border-2 border-dark-subtle" id="inputName" name="id" value="<?php echo e($report->user->first_name); ?> <?php echo e($report->user->last_name); ?>" aria-label="Disabled input example" disabled readonly>
                                        </div>
                                        <div class="col-md-3 mt-3">
                                            <label for="inputPhone" class="form-label mb-0 fs-6">Phone Number</label>
                                            <input type="text" class="form-control border-2 border-dark-subtle" id="inputPhone" name="id" value="<?php echo e($report->user->contact_no); ?>" aria-label="Disabled input example" disabled readonly>
                                        </div>
                                        <div class="col-md-3 mt-3">
                                            <label for="inputPassword4" class="form-label mb-0 fs-6">Date</label>
                                            <input type="text" class="form-control border-2 border-dark-subtle" id="inputPassword4" name="id" value="<?php echo e($report->created_at); ?>" aria-label="Disabled input example" disabled readonly>
                                        </div>
                                        <div class="col-12 mt-3">
                                            <label for="inputAddress" class="form-label mb-0">Location</label>
                                            <input type="text" class="form-control border-2 border-dark-subtle" id="inputPassword4" name="id" value="<?php echo e($report->location); ?>" aria-label="Disabled input example" disabled readonly>
                                        </div>
                                        <div class="col-12 mt-3">
                                            <label for="exampleFormControlTextarea1" class="form-label">Incident Details</label>
                                            <textarea class="form-control border-2 border-dark-subtle align-left" id="exampleFormControlTextarea1"  name="ticket_body" rows="3" aria-label="Disabled input example" disabled readonly><?php echo e($report->details); ?></textarea>
                                        </div>
                                        <div class="col-12 mt-3 mb-3">
                                            <label for="inputAddress" class="form-label mb-0">Additional Notes</label>
                                            <input type="text" class="form-control border-2 border-dark-subtle" id="inputPassword4" name="id" value="<?php echo e($report->addnote); ?>" aria-label="Disabled input example" disabled readonly>
                                        </div>
                                        
                                        </form>
                                        </div>
                                            
                                        </div>
                                    </div>
                                </div>
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Respond</button>
                                    <button type="button" class="btn btn-primary">Forward</button>
                                </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        </div>

            </div>
        </div>
    </div>

    


    


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Otap\resources\views/latest.blade.php ENDPATH**/ ?>