
<?php $__env->startSection('css'); ?>
<link href="<?php echo e(asset('css/landingpage.css')); ?>" rel="stylesheet">
<link href="<?php echo e(asset('css/sidenav.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('js'); ?>
<script src="<?php echo e(asset('path/to/maps.js')); ?>"></script>
<script src="<?php echo e(asset('js/sidenav.js')); ?>"></script>

<?php $__env->stopSection(); ?>


    <?php echo $__env->make('sidebar.sidenav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="latest-container p-4 mt-5" style="flex: 1">
        <h1>Responding Emergency</h1>

        <div class="requests" style="width: 95%; margin: 10px">
            <div class="shadow p-4 mb-4 bg-white rounded " >
                <div class="row align-items-center">
                    <div class="col">
                    <?php $__currentLoopData = $respondingIncidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($incident->type == 'Requesting for Ambulance'): ?>
                            <div class="btn btn-primary shadow p-1 mb-1 bg-white rounded " type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($incident->id); ?>" style="width: 100%; margin: 10px; border: none">
                                <div class="card-body">
                                        <div class="row align-items-center text-start">
                                            <div class="col-auto">
                                                <h1 style="color: red">|</h1>
                                            </div>
                                            <div class="col">
                                                <h6 style="color: #000"><?php echo e($incident->type); ?></h6>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        <?php elseif($incident->type == 'Requesting for a Fire Truck'): ?>
                            <div class="btn btn-primary shadow p-1 mb-1 bg-white rounded " type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($incident->id); ?>" style="width: 100%; margin: 10px; border: none">
                                <div class="card-body">
                                        <div class="row align-items-center text-start">
                                            <div class="col-auto">
                                                <h1 style="color: rgb(255, 132, 0)">|</h1>
                                            </div>
                                            <div class="col">
                                                <h6 style="color: #000"><?php echo e($incident->type); ?></h6>
                                            
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        <?php else: ?>
                            <div class="btn btn-primary shadow p-1 mb-1 bg-white rounded " type="button" data-bs-toggle="modal" data-bs-target="#exampleModal<?php echo e($incident->id); ?>" style="width: 100%; margin: 10px; border: none">
                                <div class="card-body">
                                        <div class="row align-items-center text-start">
                                            <div class="col-auto">
                                                <h1 style="color: rgb(0, 157, 255) ">|</h1>
                                            </div>
                                            <div class="col">
                                                <h6 style="color: #000"><?php echo e($incident->type); ?></h6>
                                            
                                            </div>
                                        </div>
                                    </div>
                            </div>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <!-- Modal -->
                    <?php $__currentLoopData = $respondingIncidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident_modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="modal fade" id="exampleModal<?php echo e($incident_modal->id); ?>" tabindex="-1"  aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg ">
                            <div class="modal-content ">
                                <div class="modal-header">
                                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                </div>
                    
                                <div class="modal-body justify-content-center">
                                    <!-- Google Map Container -->
                                    <div id="map<?php echo e($incident_modal->id); ?>" style="height: 300px;"></div>
                    
                                    <!-- Rest of the modal content -->
                                    <h4 style="text-align: center">Details</h4>
                                    <div class="square-container p-20">
                                        <div class="shadow p-1 mb-1 bg-white rounded">
                                            <h5>Emergency: <?php echo e($incident_modal->type); ?></h5>
                                            <h5>Name: <?php echo e($incident_modal->user->first_name); ?> <?php echo e($incident_modal->user->last_name); ?></h5>
                                            <h5>Age: <?php echo e($incident_modal->user->age); ?></h5>
                                            <h5>Address: <?php echo e($incident_modal->user->lot_no); ?> <?php echo e($incident_modal->user->street); ?> <?php echo e($incident_modal->user->barangay); ?> <?php echo e($incident_modal->user->city); ?></h5>
                                        </div>
                                    </div>
                                </div>
                    
                                <div class="modal-footer justify-content-center">
                                    <button type="button" class="btn btn-success" data-bs-dismiss="modal">Respond</button>
                                    <button type="button" class="btn btn-primary" onclick="raised()">Forward</button>

                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <script>
    // Array to store map instances
    var maps = [];

    function initMaps() {
        <?php $__currentLoopData = $respondingIncidents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $incident_modal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            initMap('map<?php echo e($incident_modal->id); ?>', <?php echo e($incident_modal->latitude); ?>, <?php echo e($incident_modal->longitude); ?>);
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    }

    function initMap(mapId, latitude, longitude) {
        var incidentLocation = { lat: latitude, lng: longitude };
        var map = new google.maps.Map(document.getElementById(mapId), {
            zoom: 18,
            center: incidentLocation
        });
        var marker = new google.maps.Marker({
            position: incidentLocation,
            map: map
        });

        // Store the map instance in the array
        maps.push({ id: mapId, map: map });
    }
</script>

<!-- Call the initMaps function once the Google Maps API is loaded -->
<script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB3sNbXeLLaZQcJiCWNzC4Rwp-xALyV4lM&callback=initMaps"></script>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Otap\resources\views/responding.blade.php ENDPATH**/ ?>